import { registerRootComponent } from "expo"
import App from "./App.tsx"

// Регистрируем корневой компонент приложения
registerRootComponent(App)
