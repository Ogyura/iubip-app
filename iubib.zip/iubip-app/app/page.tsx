"use client"

import MainTabNavigator from "../navigation/MainTabNavigator"

export default function SyntheticV0PageForDeployment() {
  return <MainTabNavigator />
}